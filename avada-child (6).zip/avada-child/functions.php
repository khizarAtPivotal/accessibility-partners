<?php
/**
 * Recommended way to include parent theme styles.
 * (Please see http://codex.wordpress.org/Child_Themes#How_to_Create_a_Child_Theme)
 *
 */  

add_action( 'wp_enqueue_scripts', 'avada_child_style' );

function avada_child_style() {
	wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css', array('parent-style'), time() );
	
	wp_enqueue_script('a11y-js', get_stylesheet_directory_uri().'/a11y.js', array('jquery'), time(), true);
	wp_enqueue_style('a11y-css', get_stylesheet_directory_uri().'/a11y.css', array(), time(), 'all');
}

function enqueue_learnpress_css_collections() {
  if ( is_singular( 'lp_collection' ) ) {
    wp_enqueue_style( 'learnpress-collections', LP_PLUGIN_URL . '/assets/css/learnpress.min.css' );
  }
}

add_action( 'wp_enqueue_scripts', 'enqueue_learnpress_css_collections' );


function avada_child_page_slug_to_body_class($classes) {
    global $post;
    
    // Check if we're on a single page
    if (is_singular()) {
        $classes[] = $post->post_name; // Adds the page slug as a class
    }
    
    return $classes;
}
add_filter('body_class', 'avada_child_page_slug_to_body_class');

add_action( 'user_registration_check_token_complete', 'a11y_partners_login_email_verification', 10, 2 );

function a11y_partners_login_email_verification($user_id, $user_reg_successful) {
	if( true === $user_reg_successful ) {
		wp_set_auth_cookie( $user_id );
		$form_id_array = get_user_meta( $user_id, '4894' );
		$form_id       = 0;
		$url = '';

		if ( isset( $form_id_array[0] ) ) {
			$form_id = $form_id_array[0];
		}

		$url = home_url(). "/lp-profile/";
		wp_safe_redirect( $url );

		die();
    }
}

add_action('admin_init', 'disable_dashboard');

function disable_dashboard(){
	if (current_user_can('subscriber') && is_admin()) {
        wp_redirect(home_url());
        exit;
    }
}