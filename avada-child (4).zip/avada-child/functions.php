<?php
/**
 * Recommended way to include parent theme styles.
 * (Please see http://codex.wordpress.org/Child_Themes#How_to_Create_a_Child_Theme)
 *
 */  

add_action( 'wp_enqueue_scripts', 'avada_child_style' );

function avada_child_style() {
	wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css', array('parent-style'), time() );
	
	wp_enqueue_script('a11y-js', get_stylesheet_directory_uri().'/a11y.js', array('jquery'), time(), true);
	wp_enqueue_style('a11y-css', get_stylesheet_directory_uri().'/a11y.css', array(), time(), 'all');
}

function enqueue_learnpress_css_collections() {
  if ( is_singular( 'lp_collection' ) ) {
    wp_enqueue_style( 'learnpress-collections', LP_PLUGIN_URL . '/assets/css/learnpress.min.css' );
  }
}

add_action( 'wp_enqueue_scripts', 'enqueue_learnpress_css_collections' );

/**
 * Your code goes below.
 */

