const focusableSelector = [
    "a[href]:not([tabindex='-1'])",
    "area[href]:not([tabindex='-1'])",
    "input:not([disabled]):not([tabindex='-1']):not([type='hidden'])",
    "select:not([disabled]):not([tabindex='-1'])",
    "textarea:not([disabled]):not([tabindex='-1'])",
    "button:not([disabled]):not([tabindex='-1'])",
    "iframe:not([tabindex='-1'])",
    "[tabindex]:not([tabindex='-1'])",
    "[contentEditable=true]:not([tabindex='-1'])",
].join(",");

function triggerSelfClick(e) {
    if (e.key === "Enter") {
        e.target.click();
    }
}

jQuery(document).ready(function () {
    const $ = jQuery;
    $("body").append('<div class="sr-only live-status-region" role="status"></div>');

    $('.skip-link').each((i, link) => {
        const content = document.querySelector("#content");

        if (!content) {
            $(link).attr('href', '#sliders-container');
        }
    });

    $('footer .fusion-title-heading').attr({
        'role': 'heading',
        'aria-level': 2
    });

    $(".current-menu-item").each((i, current) => {
        $(current).find('> a').attr({
            'aria-current': 'page'
        });
    });


    $('.awb-menu').each((i, menu) => {
        const observer = new MutationObserver((mutations) => {
            if (menu.classList.contains('expanded')) {
                trapFocus(menu, focusableSelector);
                $(menu).parents().siblings().attr("aria-hidden", true);
				$(menu).find('.awb-menu__m-toggle').attr('aria-expanded', true);
            } else {
                $(menu).parents().siblings().removeAttr("aria-hidden");
				$(menu).find('.awb-menu__m-toggle').attr('aria-expanded', false);
            }
        });

        observer.observe(menu, {
            attributes: true,
            attributeFilter: ['class']
        })
    });

    $('.switch-btn').each((i, button) => {
        $(button).attr({
            'tabindex': 0,
            'role': 'button',
            'aria-label': `${$(button).attr('title')}`
        });

        $(button).removeAttr('title');

        $(button).on('keydown', triggerSelfClick);
    });


    $('footer').each((i, footer) => {
        const info = $(footer).find('.footer__info');

        const form = $(`
              <form class="color-scheme-form">
                  <label for="color-scheme-switcher">Color Scheme</label>
                  <select class="color-scheme-switcher" id="color-scheme-switcher">
                      <option value="default">Default</option>
                      <option value="accessible">Accessible</option>
                  </select>
              </form>
          `)

        const selectedValue = localStorage.getItem('color-scheme');
        const select = form.find('#color-scheme-switcher');

        select.on('change', (e) => {
            $(':root').attr({
                'data-color-scheme': e.target.value
            });

            localStorage.setItem('color-scheme', e.target.value);
        });

        if (selectedValue) {
            $(':root').attr({
                'data-color-scheme': selectedValue || value
            });

            select.val(selectedValue);
        }

        info.find('> .fusion-column-wrapper').append(form);
    });

    $('.learn-press-breadcrumb').each((i, breadcrumb) => {
        const last = $(breadcrumb).find('> li').last();

        last.find('span').attr('aria-hidden', true);

        last.prepend(`<span class="sr-only">current page ${last.find('span').text().trim()}</span>`);

        $(breadcrumb).find('.breadcrumb-delimiter').each((i, delimiter) => {
            $(delimiter).prev().append(delimiter);

            $(delimiter).attr({
                'role': 'none',
                'aria-hidden': true
            });

            $(delimiter).find('.fa-chevron-right').attr('aria-hidden', true);
        })
    });


    $('.learn-press-courses-header').each((i, header) => {
        $(header).attr('role', 'none');

        $(header).find('h1').attr({
            'role': 'heading',
            'aria-level': 2
        });
    });

    $(".learn-press-courses").each((i, courses) => {
        function handleChange() {
            $(courses).find('.course-item').each((i, item) => {
                $(item).find('.course-readmore > a').attr({
                    'aria-label': function () {
                        return `${$(this).text().trim()} ${$(item).find('.course-title').text().trim()}`
                    }
                });

                $(item).find('.meta-item').each((i, meta) => {
                    const beforeContent = window.getComputedStyle(meta, '::before').content;
                    const classes = meta.classList;

                    $(meta).prepend(`<span class="meta-item-icon ${classes[1]}" aria-hidden="true"></span>`);

                    classes.remove(classes[1]);
                });
            });
        }

        handleChange();

        const observer = new MutationObserver((mutations) => {
            setTimeout(() => {
                handleChange();
                announceToScreenReader(`${$(courses).children('li').length} results found`);
            });
        });

        observer.observe(courses, {
            childList: true
        });
    });

    $('main:not(#main)').attr('role', 'none');

    $('button[name="lp-btn-search-courses"]').attr('aria-label', 'Search');

    $('.learn-press-nav-tabs').each((i, tabs) => {
        $(tabs).find('.course-nav').each((i, nav) => {
            $(nav).attr({
                'role': 'button',
                'tabindex': 0
            });

            $(nav).on('keydown', triggerSelfClick);
        })
    });


    $('.course-detail-info').each((i, info) => {
        $(info).find('.course-title').attr({
            'role': 'heading',
            'aria-level': 2
        });
    });

    $('.lp-checkout-form').each((i, form) => {
        $("<p class='required-indication'>Fields marked with an asterisk (*) are required.</p>").insertBefore($(form).find('#checkout-account-login .lp-form-fields'));
		
        $(form).removeAttr('tabindex');
    });

    $('.lp-archive-courses h1.lp-content-area').attr({
        'role': 'heading',
        'aria-level': 2
    });

    $('#checkout-order > h4').attr({
        'role': 'heading',
        'aria-level': 3
    });

    $('#checkout-payment').each((i, checkout) => {
        const heading = $(checkout).find('> h4');

        heading.attr({
            'role': 'heading',
            'aria-level': 3
        });

        insertHiddenClone(heading.get(0));
    });

    $('#profile-content-order-details, #checkout-order').each((i, details) => {
        const label = $(details).find('> h3, > h4');

        $(details).find('table').attr({
            'aria-label': `${label.text().trim()}`
        });

        $(details).find('> h3').attr({
            'role': 'heading',
            'aria-level': 2
        });
    });

    $('.learn-press-form-login').each((i, form) => {
        $(form).prepend("<p class='required-indication'>Fields marked with an asterisk (*) are required.</p>");

        $(form).find('input[name="username"], input[name="password"], input[name="rememberme"]').attr('required', 'required')
    });

    $('form[name="profile-change-password"]').each((i, form) => {
        $(form).prepend("<p class='required-indication'>Fields marked with an asterisk (*) are required.</p>")

        $(form).find('.form-field').each((i, field) => {
            if (!field.querySelector('.required')) {
                $(field).find('label').append(' <span class="required">*</span>');
				
				$(field).find('input').attr({
                    'required': 'required'
                });
            }
        });
    });

    $('form[name="profile-basic-information"]').each((i, form) => {
        $(form).prepend("<p class='required-indication'>Fields marked with an asterisk (*) are required.</p>");

        $(form).find('.form-field').each((i, field) => {
            if (field.querySelector('.required')) {
                $(field).find('input').attr({
                    'required': 'required'
                });
            }
        });

        $(form).find('textarea[name="description"]').each((i, description) => {
            const id = randomId();
            const describedBy = randomId();

            $(description).attr({
                'id': id,
                'aria-describedby': describedBy
            });

            $(description).closest('.form-field').children('label').attr({
                'for': id
            });

            $(description).next('.description').attr({
                'id': describedBy
            });

        });

        $(form).find('.form-field__profile-social').each((i, field) => {
            const id = randomId();

            $(field).find('input').attr('id', id);

            $(field).find('label').attr('for', id);
        });
    });

    $('#profile-content-quizzes .learn-press-filters').each((i, filters) => {
        $(filters).find('> li').each((i, li) => {
            const selected = $(li).find('> span');
            $(`<span class="sr-only">current page ${selected.text().trim()}</span>`).insertBefore(selected);
            selected.attr({
                'aria-hidden': true
            });
        })
    })

    $('.learn-press-filters').each((i, filters) => {
        $(filters).find('a[data-tab]').each((i, tab) => {
            $(tab).attr({
                'role': 'button',
                'tabindex': 0
            });

            function handleChange() {
                if (tab.classList.contains('active')) {
                    $(tab).attr('aria-current', true)
                } else {
                    $(tab).removeAttr('aria-current');
                }
            }

            handleChange();

            const observer = new MutationObserver(() => {
                handleChange();
            });

            observer.observe(tab, {
                attributes: true,
                attributeFilter: ['class']
            });
        });
    });


    $('.lp-profile-nav-tabs').each((i, tabs) => {
        $(tabs).parent().attr({
            'role': 'navigation',
            'aria-label': 'Side'
        });

        $(tabs).find('> li.has-child').each((i, li) => {
            $(li).on('keydown', (e) => {
                console.log(e.key);

                if (e.key === 'Escape') {
                    $(li).find('> ul').addClass('hidden');
                }
            })
        });

        $(tabs).find('> li.active > a').attr({
            'aria-current': true
        })
    });

    $(".learn-press-tabs").each((i, tabs) => {
        $(tabs).find('.learn-press-tabs__tab.active a').attr({
            'aria-current': true
        });
    });

    $('.profile-recover-order').each((i, order) => {
        $(order).find('.order-recover').each((i, recover) => {
            $(recover).find('input[name="order-key"]').attr('required', 'required');
        });

        const observer = new MutationObserver((mutations) => {
            const id = randomId();

            $(order).find('.error').attr('id', id);
            $(order).find('input[name="order-key"]').attr('aria-describedby', id);
        });

        observer.observe(order, {
            childList: true
        })
    });

    $('.learnpress_avatar').each((i, avatar) => {
        $(avatar).find('label').each((i, label) => {
            $(label).attr({
                'tabindex': 0,
                'role': 'button'
            });

            $(label).on('keydown', triggerSelfClick);
        });

        const observer = new MutationObserver((mutations) => {
            $(avatar).find('.lp-ajax-message').each((i, message) => {
                console.log(message.textContent.trim());
                announceToScreenReader(`${message.textContent.trim()}`);
            });
        });

        observer.observe(avatar, {
            childList: true,
        });
    });
	
	$('.lp-password-input').each((i, field) => {
		const showBtn = $(field).find('.lp-show-password-input');
		
		showBtn.attr({
			'role': 'button',
			'tabindex': 0,
			'aria-label': 'Password Visibility',
			'aria-pressed': showBtn.hasClass('display-password')
		});
		
		showBtn.on('keydown', triggerSelfClick);
		
		showBtn.on('click', () => {
			showBtn.attr('aria-pressed', showBtn.hasClass('display-password'));
		})
	});
	
	$('.learn-press-message').each((i, error) => {
		$(error).attr({
			'tabindex': -1
		}).focus();
	});
	
	$('.comment-form').each((i, form) => {
		$(form).prepend("<p class='required-indication'>Fields marked with an asterisk (*) are required.</p>");
		
		$(form).find('.screen-reader-text').removeClass('screen-reader-text');
		
		$(form).find('textarea[aria-label], input[aria-label], select[aria-label]').each((i, input) => {
			$(`<label for="${input.getAttribute('id')}">${input.getAttribute('aria-label')}</label>`).insertBefore(input);
		});
		
		$(form).find('label').each((i, label) => {
			$(label).append(`<span class="required"> *</span>`);
		});
	});
	
	$('.comment-list').each((i, list) => {
		const queryParams = new URLSearchParams(window.location.search);
		
		if(queryParams.has('unapproved')) {
			$(list).find(`#comment-${queryParams.get('unapproved')} .comment-text`).attr('tabindex', -1).focus();
		}
	})
	
	$('.comment-respond').each((i, respond) => {
		$(respond).find('.comment-reply-title').attr({
			'role': 'heading',
			'aria-level': 2
		})
	});
	
	$('.course-price').each((i, price) => {
		$(price).find('.origin-price').prepend('<span class="sr-only">Original Price: </span>');
		$(price).find('.price').prepend('<span class="sr-only">Sale Price: </span>');
	});
	
	$('img[src*="logo-creator-for-an-innovating-corporation"]').attr({
		'alt': 'Accessibility Partners Canada Logo'
	});

    console.log("Ready");
});

jQuery(window).on("load", function () {
	const $ = jQuery;
	
	$('.curriculum-sections').each((i, sections) => {
        $(sections).find('.section').each((i, section) => {
            $(section).find('.section-toggle > i').attr('aria-hidden', true);
			
			$(section).find('.section-title').attr({
				'role': 'heading',
				'aria-level': 2
			});
        });
    });
	
	$('.course-item-status').each((i, status) => {
		console.log(status);
		
		$(status).attr({
			'role': 'img',
			'aria-label': `${$(status).attr('title')}`
		});
	});

});



function trapFocus(element, focusableSelector = "input, button, a") {
    if (!element || typeof element !== "object") {
        console.error("Invalid element provided.");
        return;
    }

    const focusableElements = Array.from(element.querySelectorAll(focusableSelector));

    if (focusableElements.length === 0) {
        console.warn("No focusable elements found within the provided element.");
        return;
    }

    const firstFocusable = focusableElements[0];
    const lastFocusable = focusableElements[focusableElements.length - 1];

    firstFocusable.addEventListener("keydown", (e) => {
        if (e.key === "Tab" && e.shiftKey) {
            e.preventDefault();
            lastFocusable.focus();
        }
    });

    lastFocusable.addEventListener("keydown", (e) => {
        if (e.key === "Tab" && !e.shiftKey) {
            e.preventDefault();
            firstFocusable.focus();
        }
    });

    // Focus the first focusable element initially.
    firstFocusable.focus();
}



let liveElementTimeout = null;

function announceToScreenReader(text, role = "status", timeout = 1000, once = false) {
    const liveElement = document.querySelector(".live-status-region");

    if (!liveElement) {
        return;
    }

    liveElement.setAttribute("role", role);

    const paraElement = document.createElement("p");
    paraElement.textContent = text;
    liveElement.appendChild(paraElement);

    if (once && liveElementTimeout) {
        clearTimeout(liveElementTimeout);
    }

    liveElementTimeout = setTimeout(() => {
        liveElement.innerHTML = "";
        liveElement.setAttribute("role", "status");
        liveElementTimeout = null;
    }, timeout);
}

function insertHiddenClone(element) {
    const $ = jQuery;

    const $element = $(element);
    const headingClone = $(element).clone();
    headingClone.text($element.text().toLowerCase());
    headingClone.addClass("sr-only lowercase");

    $(headingClone).insertBefore(element);

    $element.attr({
        "aria-hidden": true,
    });
}

function randomId(length = 10) {
    const possibleCharacters =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    const possibleCharacterArray = Array.from(possibleCharacters);
    const resultArray = [];

    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * possibleCharacterArray.length);
        const randomCharacter = possibleCharacterArray[randomIndex];
        resultArray.push(randomCharacter);
    }

    return resultArray.join('');
}



