<?php
/**
 * Recommended way to include parent theme styles.
 * (Please see http://codex.wordpress.org/Child_Themes#How_to_Create_a_Child_Theme)
 *
 */  

add_action( 'wp_enqueue_scripts', 'avada_child_style' );

function avada_child_style() {
	wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css', array('parent-style'), time() );
	
	wp_enqueue_script('a11y-js', get_stylesheet_directory_uri().'/a11y.js', array('jquery'), time(), true);
	wp_enqueue_style('a11y-css', get_stylesheet_directory_uri().'/a11y.css', array(), time(), 'all');
}

function enqueue_learnpress_css_collections() {
  if ( is_singular( 'lp_collection' ) ) {
    wp_enqueue_style( 'learnpress-collections', LP_PLUGIN_URL . '/assets/css/learnpress.min.css' );
  }
}

add_action( 'wp_enqueue_scripts', 'enqueue_learnpress_css_collections' );


function avada_child_page_slug_to_body_class($classes) {
    global $post;
    
    // Check if we're on a single page
    if (is_singular()) {
        $classes[] = $post->post_name; // Adds the page slug as a class
    }
    
    return $classes;
}
add_filter('body_class', 'avada_child_page_slug_to_body_class');

add_action( 'user_registration_check_token_complete', 'a11y_partners_login_email_verification', 10, 2 );

function a11y_partners_login_email_verification($user_id, $user_reg_successful) {
	if( true === $user_reg_successful ) {
		wp_set_auth_cookie( $user_id );
		$form_id_array = get_user_meta( $user_id, '4894' );
		$form_id       = 0;
		$url = '';

		if ( isset( $form_id_array[0] ) ) {
			$form_id = $form_id_array[0];
		}

		$url = home_url(). "/lp-profile/";
		wp_safe_redirect( $url );

		die();
    }
}

add_action('admin_init', 'disable_dashboard');

function disable_dashboard(){
	if (current_user_can('subscriber') && is_admin()) {
        wp_redirect(home_url());
        exit;
    }
}

function a11y_add_profile_link_to_menu( $items, $args ) {
	if(!is_user_logged_in()) {
		return $items;
	}
	
	if($args->menu !== 'main-menu') {
		return $items;
	}
	
	$current_user = wp_get_current_user();
	$username = $current_user->user_login;
	
	$profile_link = "<li class='menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-4936 awb-menu__li awb-menu__main-li awb-menu__main-li_regular awb-menu__main-li_with-main-arrow awb-menu__main-li_with-arrow awb-menu__main-li_active-arrow-border'>
		<span class='awb-menu__main-background-default awb-menu__main-background-default_center'></span>
		<span class='awb-menu__main-background-active awb-menu__main-background-active_center'></span>
		<a href='/lp-profile' class='awb-menu__main-a awb-menu__main-a_regular'><span class='menu-text'>
			<i class='fas fa-user-circle'></i>
			$current_user->display_name</span><span class='awb-menu__open-nav-submenu-hover'></span>
		</a>
		<button type='button' aria-label='Open submenu of Profile' aria-expanded='false' class='awb-menu__open-nav-submenu_mobile awb-menu__open-nav-submenu_main'></button>
		<ul class='awb-menu__sub-ul awb-menu__sub-ul_main'>
			<li class='menu-item menu-item-type-post_type menu-item-object-page awb-menu__li awb-menu__sub-li'>
				<a class='awb-menu__sub-a' href='/lp-profile/'>Profile</a>
			</li>
			<li class='menu-item menu-item-type-post_type menu-item-object-page awb-menu__li awb-menu__sub-li'>
				<a class='awb-menu__sub-a' href='/lp-profile/$username/my-courses'>My Courses</a>
			</li>
			<li class='menu-item menu-item-type-post_type menu-item-object-page awb-menu__li awb-menu__sub-li'>
				<a class='awb-menu__sub-a' href='/lp-profile/$username/certificates'>Certificates</a>
			</li>
			<li class='menu-item menu-item-type-post_type menu-item-object-page awb-menu__li awb-menu__sub-li'>
				<a class='awb-menu__sub-a' href='/lp-profile/$username/quizzes'>Quizzes</a>
			</li>
			<li class='menu-item menu-item-type-post_type menu-item-object-page awb-menu__li awb-menu__sub-li'>
				<a class='awb-menu__sub-a' href='/lp-profile/$username/orders'>Orders</a>
			</li>
			<li class='menu-item menu-item-type-post_type menu-item-object-page awb-menu__li awb-menu__sub-li'>
				<a class='awb-menu__sub-a' href='/lp-profile/$username/settings/basic-information/'>Settings</a>
			</li>
			<li class='menu-item menu-item-type-post_type menu-item-object-page awb-menu__li awb-menu__sub-li'>
				<a class='awb-menu__sub-a' href='/lp-profile/$username/lp-logout/'>Logout</a>
			</li>
		</ul>
	</li>";
	
	$items .= $profile_link;
	
//     if ( is_user_logged_in() && $args->theme_location == 'main_navigation' ) {
//         $current_user = wp_get_current_user();
//         $profile_link = '<li><a href="' . esc_url( get_edit_profile_url( $current_user->ID ) ) . '">Profile</a></li>';
//         $items .= $profile_link;
//     }
	
    return $items;
}

add_filter( 'wp_nav_menu_items', 'a11y_add_profile_link_to_menu', 10, 2 );