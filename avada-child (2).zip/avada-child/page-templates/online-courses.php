<?php
/**
 * Template Name: Online Courses
 */

get_header();


?>

<section class="online-courses-pricing">
	<h2 class="online-courses-pricing__title">
		Online Self-Paced Document Accessibility Courses
	</h2>
	
	<div class="online-courses-pricing__items">
		<div class="online-courses-pricing__item">
			<h3>
				PDF Accessibility Course
			</h3>
			
			<ul>
				<li>"Deep Dive" into PDF accessibility.</li>
				<li>Exam preparation for IAAP CPACC (core competencies).</li>
			</ul>
			
			<div class="online-courses-pricing__item-foot">
				<p class="online-courses-pricing__item-price">$99</p>
				<p class="online-courses-pricing__item-price-info">One time payment</p>
				<a class="online-courses-pricing__item-action" href="/courses/pdf-accessibility/">Enroll Now</a>
			</div>
		</div>
		
		<div class="online-courses-pricing__item">
			<h3>
				MS Office Course
			</h3>
			<ul>
				<li>Word, Excel, and PowerPoint.</li>
				<li>Exam preparation for IAAP CPACC (core competencies).</li>
			</ul>
			
			<div class="online-courses-pricing__item-foot">
				<p class="online-courses-pricing__item-price">$199</p>
				<p class="online-courses-pricing__item-price-info">One time payment</p>
				<a class="online-courses-pricing__item-action" href="/collections/ms-office/">Enroll Now</a>
			</div>
		</div>
	
		<div class="online-courses-pricing__item">		
			<h3>
				All In One bundle
			</h3>
			
			<ul>
				<li>"Deep Dive" into documet accessibility.</li>
				<li>ALL accessibility topics: Word, Excel, PowerPoint, and PDF.</li>
				<li>Exam preparation for IAAP CPACC (core competencies).</li>
			</ul>
			
			<div class="online-courses-pricing__item-foot">
				<p class="online-courses-pricing__item-price">$299</p>
				<p class="online-courses-pricing__item-price-info">One time payment</p>
				<a class="online-courses-pricing__item-action" href="/collections/document-accessibility//">Enroll Now</a>
			</div>
		</div>
	</div>
</section>

<section class="online-courses-testimonials">
	<h2>
		The Curriculum is Effective
	</h2>
	
	<blockquote>
	  <p>I recently completed the Document Accessibility Testing Training course, and it was a game-changer for my career. The practical insights and hands-on experience were invaluable. Highly recommended!</p>
	  <footer>—Sarah Mitchell</footer>
	</blockquote>
	
	<blockquote>
	  <p>I can't thank the course instructors enough for their expertise and guidance. This training course helped me become a proficient document accessibility tester. Great job!</p>
	  <footer>—John Anderson</footer>
	</blockquote>
	
	<blockquote>
	  <p>The Document Accessibility Testing Training course was well-structured and easy to follow. I now feel confident in my ability to ensure documents are accessible to all users. Thank you!</p>
	  <footer>—Emily Baker</footer>
	</blockquote>
</section>

<?php

get_footer();